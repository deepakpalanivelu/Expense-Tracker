package com.example.theon.expensetracker;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class display_sms_details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_sms_details);
    }
}
